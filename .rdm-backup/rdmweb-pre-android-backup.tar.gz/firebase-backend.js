/* RDM V4 cloud backend: Firestore persistence + public profiles + admin/player profile controls */
const RCOL={players:'TeamPlayers',matches:'Matches',news:'News',honours:'Honours',gallery:'Gallery',socials:'Socials'};
const DEFAULT_SOCIAL_URLS={YOUTUBE:'https://www.youtube.com/@rehan_dominators_mahuawan',TELEGRAM:'https://t.me/rehandominatorsmahuawan',WHATSAPP:'https://whatsapp.com/channel/0029Vb8icRM3WHTQGQtM4G3j'};
let rdmRemoteReady=false,rdmLoading=false,rdmCropTarget=null;
const rdmStamp=()=>firebase.firestore.FieldValue.serverTimestamp();
const rdmDocData=d=>({...d.data(),_docId:d.id});
const rdmAdmin=()=>session?.mode==='admin'&&window.__rdmUrlKeyRole==='admin';
const rdmPlayer=()=>session?.mode==='player'&&window.__rdmUrlKeyRole==='player'?D.players.find(p=>p.id===session.playerId):null;
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const safeUrl=u=>/^https?:\/\//i.test(String(u||''))?String(u):'';
const rdmStaticPlayerImage=u=>/^(?:\.?\/)?assets\/(?:rehan\.png|players\/)/i.test(String(u||''));
function rdmRefresh(){window.rdmCleanStaticPlayerImages?.();render();if(session?.mode==='player')renderProfile();window.renderAdmin?.();}
async function rdmCompressFile(file,max=1000,quality=.72){
  if(!file)return'';const url=await new Promise((res,rej)=>{const r=new FileReader;r.onload=()=>res(r.result);r.onerror=rej;r.readAsDataURL(file)});
  const im=await new Promise((res,rej)=>{const x=new Image;x.onload=()=>res(x);x.onerror=rej;x.src=url});const scale=Math.min(1,max/Math.max(im.width,im.height));
  const c=document.createElement('canvas');c.width=Math.max(1,Math.round(im.width*scale));c.height=Math.max(1,Math.round(im.height*scale));c.getContext('2d').drawImage(im,0,0,c.width,c.height);
  let out=c.toDataURL('image/jpeg',quality);if(out.length>720000)out=c.toDataURL('image/jpeg',.55);if(out.length>900000)throw new Error('IMAGE_TOO_LARGE');return out;
}
async function rdmSeedIfNeeded(){if(!rdmAdmin())return;
  if((await rdmDB.collection(RCOL.players).limit(1).get()).empty){const b=rdmDB.batch();D.players.forEach((p,i)=>b.set(rdmDB.collection(RCOL.players).doc(p.id),{id:p.id,name:p.name,role:p.role,detail:p.detail,image:p.image||'',jersey:p.jersey||'',order:i+1,active:true,updatedAt:rdmStamp()}));await b.commit();}
  if((await rdmDB.collection(RCOL.honours).limit(1).get()).empty){const b=rdmDB.batch();D.honours.forEach((h,i)=>b.set(rdmDB.collection(RCOL.honours).doc('h'+String(i+1).padStart(2,'0')),{...h,order:i+1,updatedAt:rdmStamp()}));await b.commit();}
  if((await rdmDB.collection(RCOL.socials).limit(1).get()).empty){const defs=[{id:'instagram',name:'INSTAGRAM',url:'',icon:'IG',displayName:'RDM INSTAGRAM',order:1},{id:'facebook',name:'FACEBOOK',url:'',icon:'f',displayName:'RDM FACEBOOK',order:2},{id:'youtube',name:'YOUTUBE',url:DEFAULT_SOCIAL_URLS.YOUTUBE,icon:'▶',displayName:'RDM YOUTUBE',order:3},{id:'telegram',name:'TELEGRAM',url:DEFAULT_SOCIAL_URLS.TELEGRAM,icon:'✈',displayName:'RDM TELEGRAM',order:4},{id:'whatsapp',name:'WHATSAPP',url:DEFAULT_SOCIAL_URLS.WHATSAPP,icon:'◉',displayName:'RDM WHATSAPP',order:5}];const b=rdmDB.batch();defs.forEach(x=>{const{id,...z}=x;b.set(rdmDB.collection(RCOL.socials).doc(id),{...z,image:'',updatedAt:rdmStamp()})});await b.commit();}
}
const RDM_LOCAL_OVERRIDES_KEY='RDM_LOCAL_OVERRIDES_V1';
function rdmGetOverrides(){try{const o=JSON.parse(localStorage.getItem(RDM_LOCAL_OVERRIDES_KEY)||'{}');return o&&typeof o==='object'?o:{}}catch{return {}}}
function rdmSetOverrides(fn){const o=rdmGetOverrides();fn(o);try{localStorage.setItem(RDM_LOCAL_OVERRIDES_KEY,JSON.stringify(o))}catch(e){console.warn('Local override save skipped',e)}}
window.rdmGetOverrides=rdmGetOverrides;
window.rdmSetOverrides=rdmSetOverrides;
function rdmSaveCollectionOverride(key,arr){rdmSetOverrides(o=>{o.collections=o.collections||{};o.collections[key]=arr});if(typeof save==='function')save();}
window.rdmSaveCollectionOverride=rdmSaveCollectionOverride;
function rdmApplyOverridesToData(){
  const o=rdmGetOverrides();
  if(o.collections){
    ['matches','news','honours','gallery','socials'].forEach(k=>{if(Array.isArray(o.collections[k]))D[k]=o.collections[k];});
  }
  if(Array.isArray(o.extraPlayers)){
    o.extraPlayers.forEach(ep=>{if(ep&&ep.id&&!D.players.some(p=>p.id===ep.id))D.players.push(ep);});
  }
  if(o.playerProfiles){
    D.players.forEach(p=>{
      const ov=o.playerProfiles[p.id];
      if(!ov)return;
      ['name','role','detail','jersey','nick','bio','image'].forEach(k=>{
        if(ov[k]!==undefined&&ov[k]!==null)p[k]=ov[k];
      });
      if(Array.isArray(ov.socials))p.socials=ov.socials;
    });
  }
}

async function rdmLoadAll(){if(rdmLoading)return;rdmLoading=true;try{const[ps,ms,ns,hs,gs,ss,profiles]=await Promise.all([rdmDB.collection(RCOL.players).get(),rdmDB.collection(RCOL.matches).get(),rdmDB.collection(RCOL.news).get(),rdmDB.collection(RCOL.honours).get(),rdmDB.collection(RCOL.gallery).get(),rdmDB.collection(RCOL.socials).get(),rdmDB.collection('PlayerProfiles').get()]);
  if(!ps.empty)D.players=ps.docs.map(rdmDocData).sort((a,b)=>(a.order||999)-(b.order||999)).map(p=>({id:p.id,name:p.name,role:p.role,detail:p.detail,image:rdmStaticPlayerImage(p.image)?'':(p.image||''),jersey:p.jersey||'',nick:'',bio:'',socials:[],_docId:p._docId}));
  if(typeof rdmRepairRoster2026==='function')rdmRepairRoster2026();
  D.matches=ms.docs.map(rdmDocData).sort((a,b)=>(b.createdMs||0)-(a.createdMs||0));D.news=ns.docs.map(rdmDocData).sort((a,b)=>(b.createdMs||0)-(a.createdMs||0));if(!hs.empty)D.honours=hs.docs.map(rdmDocData).sort((a,b)=>(a.order||999)-(b.order||999));D.gallery=gs.docs.map(rdmDocData).sort((a,b)=>(b.createdMs||0)-(a.createdMs||0));if(!ss.empty)D.socials=ss.docs.map(rdmDocData).sort((a,b)=>(a.order||999)-(b.order||999));
  [...profiles.docs].sort((a,b)=>{const uid=rdmAuth.currentUser?.uid||'';return (a.id===uid?1:0)-(b.id===uid?1:0)}).forEach(d=>{const pr=d.data(),p=D.players.find(x=>x.id===pr.playerId);if(p){['jersey','nick','bio'].forEach(k=>{if(pr[k]!==undefined&&pr[k]!==null&&pr[k]!=='')p[k]=pr[k]});if('image' in pr&&pr.image!==undefined&&pr.image!==null)p.image=rdmStaticPlayerImage(pr.image)?'':pr.image;if(Array.isArray(pr.socials))p.socials=pr.socials;p._profileUid=d.id;}});D.players.forEach(p=>{const d=(typeof playerDefaults!=='undefined'&&playerDefaults[p.id])||null;if(d){if(!p.nick)p.nick=d.nick;if(!p.bio)p.bio=d.bio;}});if(typeof rdmRepairRoster2026==='function')rdmRepairRoster2026();rdmApplyOverridesToData();if(typeof save==='function')save();rdmRemoteReady=true;rdmRefresh();
}catch(e){console.error(e);rdmApplyOverridesToData();rdmRefresh();}finally{rdmLoading=false}}
async function rdmSyncRoster2026(){if(!rdmAdmin()||typeof rdmRoster2026==='undefined')return;const b=rdmDB.batch();Object.values(rdmRoster2026).forEach(c=>{const photoIds=['RDM007','RDM012','RDM015','RDM016','RDM017'];const data={id:c.id,name:c.name,role:c.role,detail:c.detail,jersey:c.jersey||'',order:c.order,active:true,updatedAt:rdmStamp(),...(photoIds.includes(c.id)?{image:c.image}:{})};b.set(rdmDB.collection(RCOL.players).doc(c.id),data,{merge:true})});await b.commit()}
window.rdmBackendAuthReady=async(user,account)=>{if(account?.role==='admin'){try{await rdmSeedIfNeeded();await rdmSyncRoster2026()}catch(e){console.warn('ROSTER SYNC',e)}}await rdmLoadAll()};rdmLoadAll();document.addEventListener('visibilitychange',()=>{if(!document.hidden)rdmLoadAll()});

async function rdmProfileUid(playerId){
  if(session?.mode==='player'&&session.playerId===playerId&&rdmAuth.currentUser?.uid)return rdmAuth.currentUser.uid;
  try{
    const existing=await rdmDB.collection('PlayerProfiles').where('playerId','==',playerId).limit(1).get();
    if(!existing.empty)return existing.docs[0].id;
  }catch{}
  return 'profile_'+playerId;
}
async function rdmProfileWrite(p,extra={}){
  if(!rdmAdmin()&&session?.playerId!==p.id)throw new Error('NOT_ALLOWED');
  rdmSetOverrides(o=>{
    o.playerProfiles=o.playerProfiles||{};
    o.playerProfiles[p.id]={
      ...(o.playerProfiles[p.id]||{}),
      name:p.name||'',role:p.role||'',detail:p.detail||'',
      jersey:p.jersey||'',nick:p.nick||'',bio:p.bio||'',
      ...('image' in extra?{image:extra.image}:(p.image?{image:p.image}:{})),
      socials:Array.isArray(p.socials)?p.socials.slice(0,3):[]
    };
  });
  if(typeof save==='function')save();
  try{
    const uid=await rdmProfileUid(p.id);
    const data={playerId:p.id,jersey:p.jersey||'',nick:p.nick||'',bio:p.bio||'',socials:Array.isArray(p.socials)?p.socials.slice(0,3):[],updatedAt:rdmStamp(),...extra};
    await rdmDB.collection('PlayerProfiles').doc(uid).set(data,{merge:true});
    p._profileUid=uid;
  }catch(err){console.warn('Remote profile sync skipped, saved locally',err?.code||err)}
}

function socialObj(x,i){return typeof x==='string'?{name:'SOCIAL '+(i+1),url:x}:x||{}}
const RDM_FALLBACK_LOGO='assets/rdm-logo.png?v=7400';
function playerPhotoUrl(img){const s=String(img||'').trim();if(!s||/^data:image\/svg\+xml/i.test(s)||/(?:logo\.jpg|CRICKET_YOUR_TAGLINE_HERE|rdm_crest_emblem|^assets\/(?:rehan\.png|players\/))/i.test(s))return RDM_FALLBACK_LOGO;return s;}
function profileHtml(p,editable=false,adminEdit=false){const socials=(p.socials||[]).map(socialObj).filter(s=>s.url||s.name);const sh=socials.length?`<div class="profileSocialList">${socials.map((s,i)=>`<div class="profileSocialRow"><a href="${esc(safeUrl(s.url))}" target="_blank" rel="noopener">${mini(s.name||('SOCIAL '+(i+1)))}</a></div>`).join('')}</div>`:'<p class="mutedMini">No social links</p>';
  return `<article class="profileCard publicProfileCard"><img class="profileAvatar" src="${esc(playerPhotoUrl(p.image))}" onerror="this.onerror=null;this.src='${RDM_FALLBACK_LOGO}'"><h2>${mini(p.name)}</h2><div class="profileIdentity"><div class="identityItem"><span>Player ID</span><strong>${miniId(p.id)}</strong></div><div class="identityDivider"></div><div class="identityItem"><span>Jersey Number</span><strong>${p.jersey?'#'+esc(p.jersey):'—'}</strong></div></div>${p.nick?`<p class="profileNick">${mini(p.nick)}</p>`:''}<div class="profileOfficial"><b>${mini(p.role)}</b><br>${mini(p.detail)}</div>${p.bio?`<div class="profileBio">${mini(p.bio)}</div>`:''}${sh}${editable?`<div class="profileEditHub"><button type="button" class="primary profileEditMain" onclick="openProfileEditMenu()">✎ Edit Profile</button><button type="button" class="secondary" onclick="chooseDP()">📷 Change Photo</button><button type="button" class="secondary profileDownloadMain" onclick="openProfileDownload()">⬇ Download Profile</button><button type="button" class="secondary" id="playerInstallAppBtn" data-rdm-install-btn>📲 Install My App</button></div>`:''}${adminEdit?'':''}</article>`}

render=function(){q('#players').innerHTML=D.players.map(p=>{const n=(p.name||'').toUpperCase();const lead=n==='REHAN AKHTAR'?'CAPTAIN':n==='SAIF ALI'?'VICE-CAPTAIN':n==='SOAIB AKHTAR'?'WICKET-KEEPER':'';const expanded=!!window.__rdmExpandedStats?.has(p.id);return `<article class="player clickablePlayer ${expanded?'is-stats-open':''}" data-player-id="${esc(p.id)}" onclick="openPlayerProfile('${esc(p.id)}')"><div class="photo"><img src="${esc(playerPhotoUrl(p.image))}" alt="${esc(p.name)}" onerror="this.onerror=null;this.src='${RDM_FALLBACK_LOGO}'"></div><div class="pbody">${lead?`<div class="leadershipBadge ${lead==='VICE-CAPTAIN'?'vice':lead==='WICKET-KEEPER'?'keeper':''}">${lead==='CAPTAIN'?'♛':lead==='VICE-CAPTAIN'?'★':'🧤'} ${mini(lead)}</div>`:''}<span class="simplePlayerId">${miniId(p.id)}${p.jersey?' <em>#'+esc(p.jersey)+'</em>':''}</span><h3>${mini(p.name)}</h3><b>${mini(p.role)}</b><p>${mini(p.detail)}</p>${p.nick?`<p class="squadNick">Nickname · ${mini(p.nick)}</p>`:''}</div><div class="squadCardActions"><button type="button" class="tinyBtn squadStatsToggleBtn ${expanded?'active':''}" data-toggle-stats="${esc(p.id)}" aria-expanded="${expanded}" aria-controls="squad-stats-${esc(p.id)}"><span>${expanded?'Hide Stats':'View Stats'}</span></button><button type="button" class="tinyBtn squadShareBtn" data-share-player="${esc(p.id)}" aria-label="Share ${esc(mini(p.name))} profile"><svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/></svg><span>Share</span></button>${rdmAdmin()?`<button type="button" class="tinyBtn" onclick="event.stopPropagation();editPlayer('${esc(p.id)}')">✎ Edit</button>`:''}</div>${squadStatsHtml(p,expanded)}</article>`}).join('');
 q('#honourList').innerHTML=D.honours.map((h,i)=>`<article class="honour"><div class="trophy"><img src="${h.image}" onclick="zoom('${h.image}')"></div><h3>${h.year} • ${mini(h.title)}</h3><p>${mini(h.sub)}</p>${rdmAdmin()?`<button class="tinyBtn deleteBtn" onclick="removeItem('honours',${i})">ᴅᴇʟᴇᴛᴇ</button>`:''}</article>`).join('');
 q('#matchList').innerHTML=D.matches.length?D.matches.map((m,i)=>`<article class="card"><h3>${mini(m.opponent)}</h3><p>${mini(m.date)} • ${mini(m.venue)}</p><p>${mini(m.note)}</p>${rdmAdmin()?`<button class="tinyBtn deleteBtn" onclick="removeItem('matches',${i})">ᴅᴇʟᴇᴛᴇ</button>`:''}</article>`).join(''):'<div class="empty">ɴᴏ ᴍᴀᴛᴄʜ ᴀᴅᴅᴇᴅ ʏᴇᴛ</div>';
 q('#newsList').innerHTML=D.news.length?D.news.map((n,i)=>`<article class="card"><h3>${mini(n.title)}</h3><p>${mini(n.text)}</p>${rdmAdmin()?`<button class="tinyBtn deleteBtn" onclick="removeItem('news',${i})">ᴅᴇʟᴇᴛᴇ</button>`:''}</article>`).join(''):'<div class="empty">ɴᴏ ᴀɴɴᴏᴜɴᴄᴇᴍᴇɴᴛ ʏᴇᴛ</div>';
 q('#galleryList').innerHTML=D.gallery.length?D.gallery.map((g,i)=>`<figure><img src="${g.image}" onclick="zoom(this.src)"><figcaption>${mini(g.caption||'RDM MEMORY')}</figcaption>${rdmAdmin()?`<button class="tinyBtn deleteBtn" onclick="removeItem('gallery',${i})">ᴅᴇʟᴇᴛᴇ</button>`:''}</figure>`).join(''):'<div class="empty">ɴᴏ ɢᴀʟʟᴇʀʏ ᴘʜᴏᴛᴏ ᴀᴅᴅᴇᴅ ʏᴇᴛ</div>';
 q('#socialList').innerHTML=D.socials.map((o,i)=>{o=Array.isArray(o)?{name:o[0],url:o[1],icon:'↗'}:o;const svg=window.rdmSocialSvg?.(o.name)||'';const media=(o.image&&!/CRICKET_YOUR_TAGLINE_HERE|logo\.jpg/i.test(o.image))?`<img src="${o.image}" alt="${esc(o.name)}">`:(svg||`<span>${esc(o.icon||'↗')}</span>`);const open=o.url?`<a class="primary socialAction" href="${esc(safeUrl(o.url))}" target="_blank" rel="noopener">Open</a>`:`<button class="secondary socialAction" disabled>Link Not Added</button>`;return `<article class="socialCard"><div class="socialIcon">${media}</div><h3>${mini(o.displayName||o.name)}</h3><p class="socialPlatform">${mini(o.name)}</p><div class="socialActions">${open}${rdmAdmin()?`<button class="tinyBtn socialAction" onclick="editSocial(${i})">✎ Edit</button><button class="tinyBtn socialAction danger" onclick="removeItem('socials',${i})">Delete</button>`:''}</div></article>`}).join('');updateAuthUI()};
renderProfile=function(){
  const p=rdmPlayer();
  if(!p)return;
  const av=(typeof XD!=='undefined'&&Array.isArray(XD.availability))?XD.availability.find(z=>z.playerId===p.id):null;
  const st=(typeof XD!=='undefined'&&Array.isArray(XD.stats))?(XD.stats.find(z=>z.playerId===p.id)||{}):{};
  const status=av?.status||'NOT SET';
  const n=v=>Number(v||0)||0;
  const extras=`<div class="playerPortalExtras">
    <section class="playerPortalCard">
      <div class="playerPortalAvailRow">
        <div>
          <span class="sectionKicker">Match Status</span>
          <h3>My Match Availability</h3>
          <b class="availBadge ${status==='AVAILABLE'?'available':status==='UNAVAILABLE'?'unavailable':''}">${esc(status)}</b>
        </div>
        <button type="button" class="primary" onclick="setAvailability('${esc(p.id)}')">Change Availability</button>
      </div>
    </section>
    <section class="playerPortalCard">
      <div class="sectionHead subHead"><div><span>Performance</span><h3>My Career Statistics</h3></div></div>
      <div class="playerPortalStatsGrid">
        <b>${n(st.matches)}<small>Matches</small></b>
        <b>${n(st.runs)}<small>Runs</small></b>
        <b>${n(st.highScore)}<small>High Score</small></b>
        <b>${n(st.wickets)}<small>Wickets</small></b>
        <b>${n(st.fours)} / ${n(st.sixes)}<small>4s / 6s</small></b>
        <b>${n(st.fifties)} / ${n(st.hundreds)}<small>50s / 100s</small></b>
        <b>${n(st.strikeRate)}<small>Strike Rate</small></b>
        <b>${esc(st.bestBowling||'—')}<small>Best Bowling</small></b>
        <b>${n(st.economy)}<small>Economy</small></b>
      </div>
      ${st.last5?`<p class="squadStatLines">Last 5 Form: ${esc(st.last5)} · Season: ${esc(st.season||'2027')}</p>`:''}
    </section>
  </div>`;
  q('#profileBody').innerHTML=profileHtml(p,true,false)+extras;
  window.rdmSyncInstallButtons?.();
};
window.openPlayerProfile=id=>{const p=D.players.find(x=>x.id===id);if(!p)return;let m=q('#publicProfileModal');if(!m){m=document.createElement('div');m.id='publicProfileModal';m.className='modal';m.innerHTML='<div class="dialog publicDialog"><button class="close" type="button" aria-label="Close">×</button><div id="publicProfileBody"></div></div>';document.body.appendChild(m);m.querySelector('.close').onclick=()=>m.classList.remove('show');m.addEventListener('click',e=>{if(e.target===m)m.classList.remove('show')});}q('#publicProfileBody').innerHTML=profileHtml(p,false,rdmAdmin());m.classList.add('show')};


function rdmOpenSimpleModal(title,fields,onSave){
  if(typeof window.rdmUnifiedModal==='function') return window.rdmUnifiedModal(title,fields,onSave);
  return null;
}
function closeProfileEditMenu(){document.getElementById('profileEditModal')?.remove()}
function profileEditRows(){
  return `<div class="profileEditMenu show profileEditMenuModal"><button class="profileEditRow" type="button" onclick="runProfileEditAction('photo')"><span>📷</span><b>Change Profile Photo</b><i>›</i></button><button class="profileEditRow" type="button" onclick="runProfileEditAction('resetPhoto')"><span>↺</span><b>Use RDM Logo as Photo</b><i>›</i></button><button class="profileEditRow" type="button" onclick="runProfileEditAction('jersey')"><span>🏏</span><b>Jersey Number</b><i>›</i></button><button class="profileEditRow" type="button" onclick="runProfileEditAction('nick')"><span>✦</span><b>Nickname</b><i>›</i></button><button class="profileEditRow" type="button" onclick="runProfileEditAction('bio')"><span>✎</span><b>Bio</b><i>›</i></button><button class="profileEditRow" type="button" onclick="runProfileEditAction('socials')"><span>🔗</span><b>Socials</b><i>›</i></button></div>`
}
window.openProfileEditMenu=function(){
  if(!rdmPlayer())return toast?.('Player link required');
  closeProfileEditMenu();
  const m=document.createElement('div');
  m.id='profileEditModal';
  m.className='modal show profileEditOverlay';
  m.innerHTML=`<div class="dialog rdmUnifiedDialog profileEditDialog"><button class="close" type="button">×</button><h2>EDIT PROFILE</h2>${profileEditRows()}</div>`;
  document.body.appendChild(m);
  window.rdmMiniFormUI?.(m);
  const c=m.querySelector('.close');
  if(c)c.onclick=()=>closeProfileEditMenu();
  m.addEventListener('click',e=>{if(e.target===m)closeProfileEditMenu()});
  const dlg=m.querySelector('.profileEditDialog');
  requestAnimationFrame(()=>{if(dlg)dlg.scrollTop=0});
};
window.runProfileEditAction=function(action){
  closeProfileEditMenu();
  setTimeout(()=>{
    if(action==='photo') return chooseDP();
    if(action==='resetPhoto') return window.resetOwnPhoto?.();
    if(action==='socials') return openOwnSocialManager();
    return selfEdit(action);
  },40);
};
window.resetOwnPhoto=async function(){
  const p=rdmPlayer();if(!p)return;
  p.image='';
  await rdmProfileWrite(p,{image:''});
  rdmRefresh();
  toast('Photo reset to RDM logo');
};
window.selfEdit=async k=>{
  const p=rdmPlayer();
  if(!p)return;
  const useModal=typeof window.rdmUnifiedModal==='function';
  const config={
    jersey:{title:'EDIT JERSEY NUMBER',field:{name:'value',label:'JERSEY NUMBER',value:p.jersey||''}},
    nick:{title:'EDIT NICKNAME',field:{name:'value',label:'NICKNAME',value:p.nick||''}},
    bio:{title:'EDIT BIO',field:{name:'value',label:'BIO',type:'textarea',value:p.bio||'',rows:5}},
  }[k];
  if(!config)return;
  if(useModal){
    return rdmOpenSimpleModal(config.title,[config.field],async d=>{
      p[k]=String(d.value||'').trim();
      await rdmProfileWrite(p);rdmRefresh();toast('Profile saved');
    });
  }
  return toast('Form loading')
};
window.openOwnSocialManager=function(){
  const p=rdmPlayer();if(!p)return;
  document.getElementById('ownSocialManager')?.remove();
  const socials=(p.socials||[]).map(socialObj);
  const m=document.createElement('div');m.id='ownSocialManager';m.className='modal show profileEditOverlay';
  m.innerHTML=`<div class="dialog rdmUnifiedDialog socialManagerDialog"><button class="close" type="button">×</button><h2>SOCIAL LINKS</h2><div class="socialManagerList">${socials.length?socials.map((s,i)=>`<div class="socialManagerRow"><b>${mini(s.name||('SOCIAL '+(i+1)))}</b><div><button type="button" class="tinyBtn" data-edit="${i}">✏️ ᴇᴅɪᴛ</button><button type="button" class="tinyBtn danger" data-delete="${i}">🗑️ ᴅᴇʟᴇᴛᴇ</button></div></div>`).join(''):'<p class="mutedMini">ɴᴏ ꜱᴏᴄɪᴀʟ ʟɪɴᴋꜱ</p>'}</div>${socials.length<3?'<button type="button" class="primary wide socialManagerAdd">＋ ᴀᴅᴅ ꜱᴏᴄɪᴀʟ</button>':''}</div>`;
  document.body.appendChild(m);window.rdmMiniFormUI?.(m);
  const close=()=>m.remove();m.querySelector('.close').onclick=close;m.onclick=e=>{if(e.target===m)close()};
  m.querySelector('.socialManagerAdd')?.addEventListener('click',()=>{close();addOwnSocial()});
  m.querySelectorAll('[data-edit]').forEach(b=>b.onclick=()=>{const i=+b.dataset.edit;close();editOwnSocial(i)});
  m.querySelectorAll('[data-delete]').forEach(b=>b.onclick=async()=>{const i=+b.dataset.delete;close();await deleteOwnSocial(i)});
};
window.addOwnSocial=async()=>{
  const p=rdmPlayer();if(!p)return;
  if((p.socials||[]).length>=3)return toast('ᴍᴀx 3 ꜱᴏᴄɪᴀʟꜱ');
  if(typeof window.rdmUnifiedModal==='function'){
    return rdmOpenSimpleModal('ADD SOCIAL',[
      {name:'name',label:'SOCIAL NAME',placeholder:'INSTAGRAM',required:true},
      {name:'url',label:'SOCIAL LINK',placeholder:'https://...',required:true}
    ],async d=>{
      if(!safeUrl(d.url)) {toast('ᴠᴀʟɪᴅ ʟɪɴᴋ ʀᴇǫᴜɪʀᴇᴅ');throw new Error('VALIDATION')}
      p.socials=[...(p.socials||[]),{name:String(d.name).trim()||('SOCIAL '+((p.socials||[]).length+1)),url:String(d.url).trim()}].slice(0,3);
      await rdmProfileWrite(p);rdmRefresh();toast('ꜱᴏᴄɪᴀʟ ᴀᴅᴅᴇᴅ');
    });
  }
  return toast('ꜰᴏʀᴍ ʟᴏᴀᴅɪɴɢ')
};
window.editOwnSocial=async i=>{
  const p=rdmPlayer(),s=socialObj(p?.socials?.[i],i);if(!p||!s)return;
  if(typeof window.rdmUnifiedModal==='function'){
    return rdmOpenSimpleModal('EDIT SOCIAL',[
      {name:'name',label:'SOCIAL NAME',value:s.name||''},
      {name:'url',label:'SOCIAL LINK',value:s.url||'',placeholder:'https://...',required:true}
    ],async d=>{
      if(!safeUrl(d.url)) {toast('ᴠᴀʟɪᴅ ʟɪɴᴋ ʀᴇǫᴜɪʀᴇᴅ');throw new Error('VALIDATION')}
      p.socials[i]={name:String(d.name||'').trim()||('SOCIAL '+(i+1)),url:String(d.url).trim()};
      await rdmProfileWrite(p);rdmRefresh();toast('ꜱᴏᴄɪᴀʟ ᴜᴘᴅᴀᴛᴇᴅ');
    });
  }
  return toast('ꜰᴏʀᴍ ʟᴏᴀᴅɪɴɢ')
};
window.deleteOwnSocial=async i=>{const p=rdmPlayer();if(!p)return;p.socials.splice(i,1);await rdmProfileWrite(p);rdmRefresh();toast('ꜱᴏᴄɪᴀʟ ᴅᴇʟᴇᴛᴇᴅ')};

/* V6.8.28 — restore full cloud Admin/Profile controls accidentally lost in V6.8.26. */
const originalChooseDP=window.chooseDP;
window.chooseDP=()=>{if(!rdmPlayer())return toast?.('Player link required');rdmCropTarget=rdmPlayer()?.id||null;originalChooseDP()};
window.adminChooseDP=id=>{if(!rdmAdmin())return;rdmCropTarget=id;originalChooseDP()};
window.adminResetDP=async id=>{if(!rdmAdmin())return;const p=D.players.find(x=>x.id===id);if(!p)return;p.image='';await rdmProfileWrite(p,{image:''});try{await rdmDB.collection(RCOL.players).doc(p.id).set({image:'',updatedAt:rdmStamp()},{merge:true})}catch{}rdmRefresh();if(document.getElementById('adminPlayerProfileModal')?.classList.contains('show'))window.adminOpenPlayerProfile(id);toast('Photo reset to RDM logo')};
q('#cropSave').onclick=async()=>{if(rdmCropTarget){if(!rdmAdmin()&&rdmPlayer()?.id!==rdmCropTarget)return toast?.('Not allowed')}else if(!rdmPlayer()){return toast?.('Not allowed')}const p=D.players.find(x=>x.id===(rdmCropTarget||rdmPlayer()?.id));if(!p||!crop.img)return;const src=q('#cropCanvas'),out=document.createElement('canvas');out.width=320;out.height=320;out.getContext('2d').drawImage(src,0,0,320,320);p.image=out.toDataURL('image/jpeg',.72);try{await rdmProfileWrite(p,{image:p.image});if(rdmAdmin()){try{await rdmDB.collection(RCOL.players).doc(p.id).set({image:p.image,updatedAt:rdmStamp()},{merge:true})}catch{}}q('#cropModal').classList.remove('show');const editedId=p.id;rdmCropTarget=null;rdmRefresh();window.refreshAdminSectionManager?.();if(document.getElementById('adminPlayerProfileModal')?.classList.contains('show'))window.adminOpenPlayerProfile?.(editedId);toast('Photo saved')}catch(e){console.error(e);toast('Photo save failed')}};

window.removeItem=async(k,i)=>{if(!rdmAdmin())return toast('Admin only');const item=D[k]?.[i],col=RCOL[k];if(!item||!col)return;const run=async()=>{if(item._docId){try{await rdmDB.collection(col).doc(item._docId).delete()}catch(err){console.warn('Remote delete fallback',err?.code||err)}}D[k].splice(i,1);rdmSaveCollectionOverride(k,D[k]);rdmRefresh();window.refreshAdminSectionManager?.();toast('Deleted')};if(typeof window.rdmConfirmModal==='function')return window.rdmConfirmModal('DELETE ITEM','THIS ACTION CANNOT BE UNDONE.',run);return run()};
window.editPlayer=id=>{if(rdmAdmin())openEdit('editPlayer',D.players.find(x=>x.id===id))};
window.editSocial=i=>{if(rdmAdmin())openEdit('editSocial',D.socials[i])};
openEdit=function(mode,obj=null){if(!rdmAdmin())return toast('Admin only');editMode=mode;editObj=obj;let h='',f='';const fi='<label>Image<input id="efile" type="file" accept="image/*"></label>';
 if(mode==='match'){h='Add Match';f='<label>Opponent<input id="e1"></label><label>Date / Time<input id="e2"></label><label>Venue<input id="e3"></label><label>Detail / Result / POTM<textarea id="e4"></textarea></label>'}
 if(mode==='news'){h='Add News';f='<label>Title<input id="e1"></label><label>Announcement<textarea id="e2"></textarea></label>'}
 if(mode==='player'){h='Add Player';f='<label>Name<input id="e1"></label><label>Role<input id="e2"></label><label>Playing Detail<textarea id="e3"></textarea></label>'+fi}
 if(mode==='honour'){h='Add Honour';f='<label>Year<input id="e1"></label><label>Result<input id="e2"></label><label>Tournament<input id="e3"></label>'+fi}
 if(mode==='gallery'){h='Add Photo';f=fi+'<label>Caption<input id="e1"></label><label>Album<select id="e2"><option>TEAM PHOTOS</option><option selected>MEMORIES</option><option>UPDATES</option></select></label>'}
 if(mode==='social'){h='Add Social';f='<label>Platform<input id="e1" placeholder="INSTAGRAM"></label><label>Display Name<input id="e4" placeholder="RDM INSTAGRAM"></label><label>Link<input id="e2" placeholder="https://..."></label><label>Icon<input id="e3" placeholder="IG"></label>'+fi}
 if(mode==='editSocial'){h='Edit Social';f=`<label>Platform<input id="e1" value="${esc(obj.name||'')}"></label><label>Display Name<input id="e4" value="${esc(obj.displayName||obj.name||'')}"></label><label>Link<input id="e2" value="${esc(obj.url||'')}"></label><label>Icon<input id="e3" value="${esc(obj.icon||'')}"></label>${fi}`}
 if(mode==='editPlayer'){h='Edit Player';f=`<label>Name<input id="e1" value="${esc(obj.name)}"></label><label>Role<input id="e2" value="${esc(obj.role)}"></label><label>Playing Detail<textarea id="e3">${esc(obj.detail)}</textarea></label><label>Jersey<input id="e4" value="${esc(obj.jersey||'')}"></label><label>Nickname<input id="e5" value="${esc(obj.nick||'')}"></label><label>Bio<textarea id="e6">${esc(obj.bio||'')}</textarea></label>${fi}`}
 q('#editTitle').textContent=h;q('#editFields').innerHTML=f;q('#editor').classList.add('show');window.rdmMiniFormUI?.(q('#editor'))};
q('#editForm').onsubmit=async e=>{e.preventDefault();if(!rdmAdmin())return toast('Admin only');const v=id=>q('#'+id)?.value?.trim()||'',file=q('#efile')?.files?.[0];try{let img='';if(file)img=await rdmCompressFile(file);const now=Date.now(),localId='loc_'+now;
 if(editMode==='match'){const rec={opponent:v('e1'),date:v('e2'),venue:v('e3'),note:v('e4'),createdMs:now,_docId:localId};try{const ref=await rdmDB.collection(RCOL.matches).add({...rec,updatedAt:rdmStamp()});rec._docId=ref.id}catch{}D.matches.unshift(rec);rdmSaveCollectionOverride('matches',D.matches)}
 if(editMode==='news'){const rec={title:v('e1'),text:v('e2'),createdMs:now,_docId:localId};try{const ref=await rdmDB.collection(RCOL.news).add({...rec,updatedAt:rdmStamp()});rec._docId=ref.id}catch{}D.news.unshift(rec);rdmSaveCollectionOverride('news',D.news)}
 if(editMode==='player'){const nums=D.players.map(p=>+String(p.id).replace(/\D/g,'')).filter(Number.isFinite),id='RDM'+String(Math.max(0,...nums)+1).padStart(3,'0');const np={id,name:v('e1'),role:v('e2'),detail:v('e3'),image:img||'',jersey:'',nick:'',bio:'',socials:[],order:D.players.length+1,_docId:id};D.players.push(np);rdmSetOverrides(o=>{o.extraPlayers=o.extraPlayers||[];o.extraPlayers.push(np)});try{await rdmDB.collection(RCOL.players).doc(id).set({...np,active:true,updatedAt:rdmStamp()})}catch{}}
 if(editMode==='honour'){const rec={year:v('e1'),title:v('e2'),sub:v('e3'),image:img||RDM_FALLBACK_LOGO,order:D.honours.length+1,createdMs:now,_docId:localId};try{const ref=await rdmDB.collection(RCOL.honours).add({...rec,updatedAt:rdmStamp()});rec._docId=ref.id}catch{}D.honours.unshift(rec);rdmSaveCollectionOverride('honours',D.honours)}
 if(editMode==='gallery'){if(!img)return toast('Select an image');const rec={image:img,caption:v('e1')||'RDM MEMORY',album:v('e2')||'MEMORIES',createdMs:now,_docId:localId};try{const ref=await rdmDB.collection(RCOL.gallery).add({...rec,updatedAt:rdmStamp()});rec._docId=ref.id}catch{}D.gallery.unshift(rec);rdmSaveCollectionOverride('gallery',D.gallery)}
 if(editMode==='social'){const rec={name:v('e1'),displayName:v('e4')||v('e1'),url:v('e2'),icon:v('e3')||'↗',image:img||'',order:D.socials.length+1,_docId:localId};try{const ref=await rdmDB.collection(RCOL.socials).add({...rec,updatedAt:rdmStamp()});rec._docId=ref.id}catch{}D.socials.push(rec);rdmSaveCollectionOverride('socials',D.socials)}
 if(editMode==='editSocial'){editObj.name=v('e1');editObj.displayName=v('e4')||v('e1');editObj.url=v('e2');editObj.icon=v('e3')||editObj.icon||'↗';if(img)editObj.image=img;if(editObj._docId){try{await rdmDB.collection(RCOL.socials).doc(editObj._docId).set({name:editObj.name,displayName:editObj.displayName,url:editObj.url,icon:editObj.icon,...(img?{image:img}:{}),updatedAt:rdmStamp()},{merge:true})}catch{}}rdmSaveCollectionOverride('socials',D.socials)}
 if(editMode==='editPlayer'){const p=editObj;p.name=v('e1');p.role=v('e2');p.detail=v('e3');p.jersey=v('e4');p.nick=v('e5');p.bio=v('e6');if(img)p.image=img;try{await rdmDB.collection(RCOL.players).doc(p.id).set({name:p.name,role:p.role,detail:p.detail,jersey:p.jersey,...(img?{image:img}:{}),updatedAt:rdmStamp()},{merge:true})}catch{}await rdmProfileWrite(p,{name:p.name,role:p.role,detail:p.detail,...(img?{image:img}:{})})}
 q('#editor').classList.remove('show');rdmRefresh();window.refreshAdminSectionManager?.();toast('Saved')}catch(e){console.error(e);toast(e.message==='IMAGE_TOO_LARGE'?'Image too large':'Save failed')}};
rdmRefresh();

function rdmCanvasRoundRect(ctx,x,y,w,h,r,fill,stroke){
  r=Math.min(r,w/2,h/2);ctx.beginPath();ctx.moveTo(x+r,y);ctx.arcTo(x+w,y,x+w,y+h,r);ctx.arcTo(x+w,y+h,x,y+h,r);ctx.arcTo(x,y+h,x,y,r);ctx.arcTo(x,y,x+w,y,r);ctx.closePath();if(fill){ctx.fillStyle=fill;ctx.fill()}if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=2;ctx.stroke()}
}
function rdmWrapCanvasText(ctx,text,x,y,maxWidth,lineHeight,maxLines=5){
  const words=String(text||'').replace(/\s+/g,' ').trim().split(' ');let line='',lines=[];
  for(const word of words){const test=line?line+' '+word:word;if(ctx.measureText(test).width>maxWidth&&line){lines.push(line);line=word}else line=test;if(lines.length>=maxLines)break}
  if(line&&lines.length<maxLines)lines.push(line);lines.slice(0,maxLines).forEach((ln,i)=>ctx.fillText(ln,x,y+i*lineHeight));return lines.length*lineHeight;
}
function rdmLoadImage(src){return new Promise((resolve,reject)=>{const im=new Image();im.onload=()=>resolve(im);im.onerror=reject;im.src=src})}
function rdmExportMini(v){
  if(typeof window.rdmMiniText==='function')return window.rdmMiniText(String(v??''));
  if(typeof mini==='function')return mini(String(v??''));
  return String(v??'');
}
function rdmCanvasFont(ctx,weight,size){ctx.font=`${weight} ${size}px "Noto Sans", "Arial Unicode MS", Arial, sans-serif`}
async function rdmDrawProfileImage(format='png'){
  const p=rdmPlayer();if(!p)return;
  /* 4:5 profile-only export: no browser/UI chrome, no dark/black area. */
  const W=1080,H=1350,c=document.createElement('canvas');c.width=W;c.height=H;const ctx=c.getContext('2d');
  const bg=ctx.createLinearGradient(0,0,W,H);bg.addColorStop(0,'#f0faff');bg.addColorStop(.48,'#fffbea');bg.addColorStop(1,'#effff6');ctx.fillStyle=bg;ctx.fillRect(0,0,W,H);
  rdmCanvasRoundRect(ctx,34,34,W-68,H-68,44,'rgba(255,255,255,.97)','#b7ddec');
  const band=ctx.createLinearGradient(80,0,W-80,0);band.addColorStop(0,'#2e8ff2');band.addColorStop(.55,'#36c6dc');band.addColorStop(1,'#2bc793');rdmCanvasRoundRect(ctx,70,70,W-140,10,5,band,null);
  let logo=null;try{logo=await rdmLoadImage(RDM_FALLBACK_LOGO)}catch{}
  if(logo){ctx.save();ctx.beginPath();ctx.arc(105,132,38,0,Math.PI*2);ctx.clip();ctx.drawImage(logo,67,94,76,76);ctx.restore();ctx.strokeStyle='#d3b34f';ctx.lineWidth=3;ctx.beginPath();ctx.arc(105,132,40,0,Math.PI*2);ctx.stroke()}
  ctx.textAlign='left';ctx.fillStyle='#174f82';rdmCanvasFont(ctx,900,26);ctx.fillText(rdmExportMini('REHAN DOMINATORS MAHUAWAN'),165,128);ctx.fillStyle='#6f879b';rdmCanvasFont(ctx,700,15);ctx.fillText(rdmExportMini('MAHUAWAN • GOPALGANJ • BIHAR'),165,155);
  let avatar=null;try{avatar=await rdmLoadImage(playerPhotoUrl(p.image))}catch{try{avatar=await rdmLoadImage(RDM_FALLBACK_LOGO)}catch{}}
  if(avatar){ctx.save();ctx.beginPath();ctx.arc(W/2,315,132,0,Math.PI*2);ctx.clip();const s=Math.max(264/avatar.width,264/avatar.height),dw=avatar.width*s,dh=avatar.height*s;ctx.drawImage(avatar,W/2-dw/2,315-dh/2,dw,dh);ctx.restore();ctx.strokeStyle='#26bd94';ctx.lineWidth=10;ctx.beginPath();ctx.arc(W/2,315,138,0,Math.PI*2);ctx.stroke();ctx.strokeStyle='#ffffff';ctx.lineWidth=4;ctx.beginPath();ctx.arc(W/2,315,143,0,Math.PI*2);ctx.stroke()}
  ctx.textAlign='center';ctx.fillStyle='#174f82';rdmCanvasFont(ctx,900,42);ctx.fillText(rdmExportMini(p.name||'PLAYER'),W/2,505);
  rdmCanvasRoundRect(ctx,120,545,840,120,26,'#eef8ff','#c5e1ee');ctx.fillStyle='#d59a1c';rdmCanvasFont(ctx,900,15);ctx.fillText(rdmExportMini('PLAYER ID'),330,583);ctx.fillText(rdmExportMini('JERSEY NUMBER'),750,583);ctx.fillStyle='#174f82';rdmCanvasFont(ctx,900,27);ctx.fillText(rdmExportMini(p.id||'—'),330,627);ctx.fillText(rdmExportMini(p.jersey?'#'+p.jersey:'—'),750,627);ctx.strokeStyle='#6e8ba1';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(540,564);ctx.lineTo(540,648);ctx.stroke();
  let y=712;
  if(p.nick){ctx.fillStyle='#5c7890';rdmCanvasFont(ctx,800,19);ctx.fillText(rdmExportMini(p.nick),W/2,y);y+=48}
  const roleH=140;rdmCanvasRoundRect(ctx,120,y,840,roleH,26,'#f4f9ff','#c6e0ed');ctx.fillStyle='#315f83';rdmCanvasFont(ctx,900,22);ctx.fillText(rdmExportMini(p.role||''),W/2,y+43);rdmCanvasFont(ctx,750,18);rdmWrapCanvasText(ctx,rdmExportMini(p.detail||''),W/2,y+82,740,28,2);y+=roleH+52;
  if(p.bio){ctx.fillStyle='#526f87';rdmCanvasFont(ctx,700,18);const used=rdmWrapCanvasText(ctx,rdmExportMini(p.bio),W/2,y,780,28,4);y+=used+28}
  const socials=(p.socials||[]).map(socialObj).filter(s=>s.name||s.url).slice(0,3);
  if(socials.length){const sh=56+socials.length*32;rdmCanvasRoundRect(ctx,135,y,810,sh,20,'#f8fcff','#d4e7ef');ctx.fillStyle='#d59a1c';rdmCanvasFont(ctx,900,15);ctx.fillText(rdmExportMini('SOCIALS'),W/2,y+29);ctx.fillStyle='#466c89';rdmCanvasFont(ctx,700,16);socials.forEach((s,i)=>ctx.fillText(rdmExportMini(s.name||('SOCIAL '+(i+1))),W/2,y+62+i*30));y+=sh+18}
  const footerY=Math.min(1272,Math.max(1220,y+32));ctx.fillStyle='#d59a1c';rdmCanvasFont(ctx,900,15);ctx.fillText(rdmExportMini('ONE TEAM • ONE DREAM • ONE DOMINATION'),W/2,footerY);ctx.fillStyle='#7890a3';rdmCanvasFont(ctx,700,13);ctx.fillText(rdmExportMini('OFFICIAL PLAYER PROFILE • RDM'),W/2,footerY+30);
  const mime=format==='jpg'?'image/jpeg':'image/png',ext=format==='jpg'?'jpg':'png';const url=c.toDataURL(mime,format==='jpg'?.95:1);const a=document.createElement('a');a.href=url;a.download=`${String(p.id||'RDM')}-${String(p.name||'PLAYER').replace(/\s+/g,'-')}-PROFILE.${ext}`;document.body.appendChild(a);a.click();a.remove();toast?.(`ᴘʀᴏꜰɪʟᴇ ${ext.toUpperCase()} ʀᴇᴀᴅʏ`)
}
window.openProfileDownload=function(){
  document.getElementById('profileDownloadModal')?.remove();const m=document.createElement('div');m.id='profileDownloadModal';m.className='modal show profileDownloadOverlay';m.innerHTML=`<div class="dialog rdmUnifiedDialog profileDownloadDialog"><button class="close" type="button">×</button><h2>DOWNLOAD PROFILE</h2><p class="profileDownloadNote">ᴄʜᴏᴏꜱᴇ ɪᴍᴀɢᴇ ꜰᴏʀᴍᴀᴛ</p><div class="profileDownloadChoices"><button type="button" class="primary" data-format="png">⬇ ᴘɴɢ • ʙᴇꜱᴛ ǫᴜᴀʟɪᴛʏ</button><button type="button" class="secondary" data-format="jpg">⬇ ᴊᴘɢ • ꜱᴍᴀʟʟᴇʀ ꜰɪʟᴇ</button></div></div>`;document.body.appendChild(m);window.rdmMiniFormUI?.(m);const close=()=>m.remove();m.querySelector('.close').onclick=close;m.addEventListener('click',e=>{if(e.target===m)close()});m.querySelectorAll('[data-format]').forEach(b=>b.onclick=async()=>{const f=b.dataset.format;b.disabled=true;try{await rdmDrawProfileImage(f);close()}catch(e){console.error(e);toast?.('ᴅᴏᴡɴʟᴏᴀᴅ ꜰᴀɪʟᴇᴅ');b.disabled=false}})
};

window.toggleProfileEditMenu=function(force){ if(force===false) closeProfileEditMenu(); else openProfileEditMenu(); };


/* V6.8.67 FULL PROFILE + STATS INSIDE SQUAD */
if(!window.__rdmExpandedStats)window.__rdmExpandedStats=new Set();
function squadStatsHtml(p,expanded=false){
  const s=(typeof XD!=='undefined'&&XD.stats||[]).find(z=>z.playerId===p.id)||{};
  const n=v=>Number(v||0)||0;
  return `<div class="squadStats squadStatsPanel" id="squad-stats-${esc(p.id)}" ${expanded?'':'hidden'}>
    <div class="squadStatsGroup">
      <div class="squadStatsGroupTitle">Batting Statistics</div>
      <div class="squadStatsGrid">
        <b>${n(s.matches)}<small>Matches</small></b>
        <b>${n(s.runs)}<small>Runs</small></b>
        <b>${n(s.highScore)}<small>High Score</small></b>
        <b>${n(s.ballsFaced)}<small>Balls Faced</small></b>
        <b>${n(s.strikeRate)}<small>Strike Rate</small></b>
        <b>${n(s.fours)} / ${n(s.sixes)}<small>4s / 6s</small></b>
        <b>${n(s.fifties)} / ${n(s.hundreds)}<small>50s / 100s</small></b>
        <b>${n(s.runOuts)}<small>Run Outs</small></b>
      </div>
    </div>
    <div class="squadStatsGroup">
      <div class="squadStatsGroupTitle">Bowling Statistics</div>
      <div class="squadStatsGrid squadStatsGridBowling">
        <b>${n(s.wickets)}<small>Wickets</small></b>
        <b>${esc(s.bestBowling||'—')}<small>Best Bowling</small></b>
        <b>${n(s.economy)}<small>Economy</small></b>
      </div>
    </div>
    <div class="squadStatLines">
      <p>Last 5: ${esc(s.last5||'—')} · Season: ${esc(s.season||'2027')}</p>
    </div>
  </div>`;
}
function squadCardActionsHtml(p,expanded=false){
  const label=mini(p?.name||'Player');
  return `<div class="squadCardActions">
    <button type="button" class="tinyBtn squadStatsToggleBtn ${expanded?'active':''}" data-toggle-stats="${esc(p.id)}" aria-expanded="${expanded}" aria-controls="squad-stats-${esc(p.id)}">
      <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>
      <span>${expanded?'Hide Stats':'View Stats'}</span>
    </button>
    <button type="button" class="tinyBtn squadShareBtn" data-share-player="${esc(p.id)}" aria-label="Share ${esc(label)} profile">
      <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/></svg>
      <span>Share Profile</span>
    </button>
  </div>`;
}
function renderSquadFullProfiles(){const box=q('#players');if(!box)return;box.innerHTML=D.players.map(p=>{const n=(p.name||'').toUpperCase(),lead=n==='REHAN AKHTAR'?'CAPTAIN':n==='SAIF ALI'?'VICE-CAPTAIN':n==='SOAIB AKHTAR'?'WICKET-KEEPER':'';const socials=(p.socials||[]).map(socialObj).filter(s=>s.url||s.name);const expanded=!!window.__rdmExpandedStats?.has(p.id);return `<article class="player squadFullProfile ${expanded?'is-stats-open':''}" data-player-id="${esc(p.id)}">${rdmAdmin()?`<button type="button" class="squadEditFab" aria-label="Edit ${esc(p.name)}" title="Edit" onclick="openSquadEditMenu('${esc(p.id)}')">✎</button>`:''}<div class="photo"><img src="${esc(playerPhotoUrl(p.image))}" alt="${esc(p.name)}" onerror="this.onerror=null;this.src='${RDM_FALLBACK_LOGO}'"></div><div class="pbody">${lead?`<div class="leadershipBadge ${lead==='VICE-CAPTAIN'?'vice':lead==='WICKET-KEEPER'?'keeper':''}">${lead==='CAPTAIN'?'♛':lead==='VICE-CAPTAIN'?'★':'🧤'} ${mini(lead)}</div>`:''}<div class="squadIdentity"><span>${miniId(p.id)}</span><span>${p.jersey?'#'+esc(p.jersey):'—'}</span></div><h3>${mini(p.name)}</h3><b>${mini(p.role)}</b><p>${mini(p.detail)}</p>${p.nick?`<p class="squadNick">Nickname · ${mini(p.nick)}</p>`:''}${p.bio?`<div class="profileBio">${mini(p.bio)}</div>`:''}${socials.length?`<div class="squadSocials">${socials.map((s,i)=>`<a href="${esc(safeUrl(s.url))}" target="_blank" rel="noopener">${mini(s.name||('SOCIAL '+(i+1)))}</a>`).join('')}</div>`:''}</div>${squadCardActionsHtml(p,expanded)}${squadStatsHtml(p,expanded)}</article>`}).join('')}
window.toggleSquadPlayerStats=function(id,btn){
  const card=btn?.closest('.player')||document.querySelector(`#players .player[data-player-id="${CSS.escape(id)}"]`);
  const panel=document.getElementById(`squad-stats-${id}`)||card?.querySelector('.squadStatsPanel');
  if(!card||!panel)return;
  const open=panel.hidden;
  panel.hidden=!open;
  card.classList.toggle('is-stats-open',open);
  if(open)window.__rdmExpandedStats.add(id);else window.__rdmExpandedStats.delete(id);
  const toggleBtn=card.querySelector('[data-toggle-stats]');
  if(toggleBtn){
    toggleBtn.classList.toggle('active',open);
    toggleBtn.setAttribute('aria-expanded',String(open));
    const span=toggleBtn.querySelector('span');
    if(span)span.textContent=open?'Hide Stats':'View Stats';
  }
};
if(!window.__rdmStatsToggleDelegated){
  window.__rdmStatsToggleDelegated=true;
  document.addEventListener('click',e=>{
    const btn=e.target.closest?.('[data-toggle-stats]');
    if(!btn)return;
    e.preventDefault();
    e.stopPropagation();
    window.toggleSquadPlayerStats?.(btn.dataset.toggleStats,btn);
  });
}
window.openPlayerShareModal=function(id){
  const p=(D.players||[]).find(x=>x.id===id);
  if(!p)return;
  document.getElementById('playerShareModal')?.remove();
  const name=mini(p.name||'Player');
  const role=mini(p.role||'Squad Player');
  const avatar=playerPhotoUrl(p.image);
  const shareUrl=`${location.origin}${location.pathname}#player=${encodeURIComponent(p.id)}`;
  const shareText=`${name} (${role}) — Rehan Dominators Mahuawan Official Squad`;
  const waHref=`https://wa.me/?text=${encodeURIComponent(shareText+'\n'+shareUrl)}`;
  const xHref=`https://twitter.com/intent/tweet?text=${encodeURIComponent(shareText)}&url=${encodeURIComponent(shareUrl)}`;
  const fbHref=`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}&quote=${encodeURIComponent(shareText)}`;
  const tgHref=`https://t.me/share/url?url=${encodeURIComponent(shareUrl)}&text=${encodeURIComponent(shareText)}`;
  const hasNative=typeof navigator.share==='function';
  const m=document.createElement('div');
  m.id='playerShareModal';
  m.className='modal show rdmUnifiedModal';
  m.innerHTML=`<div class="dialog rdmUnifiedDialog playerShareDialog" role="dialog" aria-modal="true" aria-labelledby="shareModalTitle">
    <button class="close" type="button" aria-label="Close">×</button>
    <div class="sharePlayerPreview">
      <img src="${esc(avatar)}" alt="${esc(name)}" referrerPolicy="no-referrer">
      <div>
        <span class="shareKicker">Share Player Profile</span>
        <h2 id="shareModalTitle">${esc(name)}</h2>
        <p>${esc(role)} · ${esc(miniId(p.id))}${p.jersey?' · #'+esc(p.jersey):''}</p>
      </div>
    </div>
    <div class="shareChannelGrid">
      <a class="shareChannelBtn wa" href="${esc(waHref)}" target="_blank" rel="noopener noreferrer">${window.rdmSocialSvg?.('WHATSAPP')||''}<span>WhatsApp</span></a>
      <a class="shareChannelBtn x" href="${esc(xHref)}" target="_blank" rel="noopener noreferrer"><span>X / Twitter</span></a>
      <a class="shareChannelBtn fb" href="${esc(fbHref)}" target="_blank" rel="noopener noreferrer">${window.rdmSocialSvg?.('FACEBOOK')||''}<span>Facebook</span></a>
      <a class="shareChannelBtn tg" href="${esc(tgHref)}" target="_blank" rel="noopener noreferrer">${window.rdmSocialSvg?.('TELEGRAM')||''}<span>Telegram</span></a>
    </div>
    <div class="shareUrlBox">
      <input type="text" readonly value="${esc(shareUrl)}" aria-label="Shareable player profile URL">
      <button type="button" class="primary" id="shareCopyBtn">Copy Link</button>
    </div>
    ${hasNative?'<button type="button" class="secondary wide shareNativeBtn" id="shareNativeBtn">Share via Device</button>':''}
  </div>`;
  document.body.appendChild(m);
  const close=()=>{document.removeEventListener('keydown',onKey);m.remove()};
  const onKey=e=>{if(e.key==='Escape')close()};
  document.addEventListener('keydown',onKey);
  m.querySelector('.close').onclick=close;
  m.addEventListener('click',e=>{if(e.target===m)close()});
  const urlInput=m.querySelector('.shareUrlBox input');
  urlInput.addEventListener('focus',()=>urlInput.select());
  const copyBtn=m.querySelector('#shareCopyBtn');
  copyBtn.addEventListener('click',async()=>{
    let copied=false;
    try{
      if(navigator.clipboard?.writeText){await navigator.clipboard.writeText(shareUrl);copied=true;}
    }catch{}
    if(!copied){
      try{urlInput.focus();urlInput.select();copied=document.execCommand('copy');}catch{}
    }
    if(copied){
      copyBtn.textContent='Copied!';
      toast?.('Profile link copied');
      setTimeout(()=>{if(copyBtn.isConnected)copyBtn.textContent='Copy Link'},1800);
    }else{
      urlInput.focus();urlInput.select();
      toast?.('Select and copy the link');
    }
  });
  m.querySelector('#shareNativeBtn')?.addEventListener('click',async()=>{
    try{
      await navigator.share({title:`${name} · RDM`,text:shareText,url:shareUrl});
    }catch(err){
      if(err&&err.name==='AbortError')return;
      copyBtn.click();
    }
  });
};
if(!window.__rdmShareDelegated){
  window.__rdmShareDelegated=true;
  document.addEventListener('click',e=>{
    const btn=e.target.closest?.('[data-share-player]');
    if(!btn)return;
    e.preventDefault();
    e.stopPropagation();
    window.openPlayerShareModal?.(btn.dataset.sharePlayer);
  });
}
window.openSquadEditMenu=function(id){if(!rdmAdmin())return;document.getElementById('squadEditModal')?.remove();const p=D.players.find(x=>x.id===id);if(!p)return;const m=document.createElement('div');m.id='squadEditModal';m.className='modal show';m.innerHTML=`<div class="dialog rdmUnifiedDialog squadEditDialog"><button class="close" type="button" aria-label="Close">×</button><h2>Edit ${mini(p.name)}</h2><div class="squadEditChoices"><button class="squadEditChoice" type="button">📷 <span><b>Change Player Photo</b><small>Upload &amp; crop circular DP</small></span></button><button class="squadEditChoice" type="button">👤 <span><b>Player Details</b><small>Name · Role · Jersey · Bio</small></span></button><button class="squadEditChoice" type="button">📊 <span><b>Player Stats</b><small>Matches · Runs · Wickets · Career</small></span></button></div></div>`;document.body.appendChild(m);const choices=m.querySelectorAll('.squadEditChoice');choices[0].onclick=()=>{m.remove();adminChooseDP(id)};choices[1].onclick=()=>{m.remove();editPlayer(id)};choices[2].onclick=()=>{m.remove();editStats(id)};m.querySelector('.close').onclick=()=>m.remove();m.onclick=e=>{if(e.target===m)m.remove()}}
const renderBeforeSquadFull=render;render=function(){renderBeforeSquadFull();renderSquadFullProfiles()};


/* V6.8.97 — isolated Admin Player Profile Manager. Every save targets exactly one player document. */
window.adminOpenPlayerProfile=function(id){
  if(!rdmAdmin())return toast('ᴀᴅᴍɪɴ ᴏɴʟʏ');
  const p=D.players.find(x=>x.id===id);if(!p)return;
  let m=document.getElementById('adminPlayerProfileModal');
  if(!m){m=document.createElement('div');m.id='adminPlayerProfileModal';m.className='modal';m.innerHTML='<div class="dialog publicDialog adminPlayerDialog"><button class="close" type="button">×</button><div id="adminPlayerProfileBody"></div></div>';document.body.appendChild(m);m.querySelector('.close').onclick=()=>m.classList.remove('show');m.onclick=e=>{if(e.target===m)m.classList.remove('show')}}
  document.getElementById('adminPlayerProfileBody').innerHTML=profileHtml(p,false,false)+`<div class="adminPlayerActions"><button class="primary" onclick="adminEditPlayerProfile('${p.id}')">✎ Edit Profile</button><button class="secondary" onclick="editPlayer('${p.id}')">✎ Details &amp; Role</button><button class="secondary" onclick="editStats('${p.id}')">📊 Edit Stats</button><button class="secondary" onclick="setAvailability('${p.id}')">✓ Availability</button><button class="secondary" onclick="adminChooseDP('${p.id}')">📷 Change Photo</button><button class="tinyBtn danger" onclick="adminResetDP('${p.id}')">↺ Reset to Logo</button></div>`;
  m.classList.add('show');
};
window.adminEditPlayerProfile=function(id){
  if(!rdmAdmin())return;const p=D.players.find(x=>x.id===id);if(!p)return;
  rdmOpenSimpleModal('EDIT PLAYER PROFILE',[
    {name:'jersey',label:'JERSEY NUMBER',value:p.jersey||''},
    {name:'nick',label:'NICKNAME',value:p.nick||''},
    {name:'bio',label:'BIO',type:'textarea',value:p.bio||'',rows:5},
    {name:'social1',label:'SOCIAL 1 LINK',value:(socialObj(p.socials?.[0],0).url||'')},
    {name:'social2',label:'SOCIAL 2 LINK',value:(socialObj(p.socials?.[1],1).url||'')},
    {name:'social3',label:'SOCIAL 3 LINK',value:(socialObj(p.socials?.[2],2).url||'')}
  ],async d=>{
    const links=[d.social1,d.social2,d.social3].map(x=>String(x||'').trim()).filter(Boolean);
    if(links.some(x=>!safeUrl(x))){toast('ᴠᴀʟɪᴅ ꜱᴏᴄɪᴀʟ ʟɪɴᴋ ʀᴇǫᴜɪʀᴇᴅ');throw Error('VALIDATION')}
    const nextSocials=links.map((url,i)=>({name:p.socials?.[i]?.name||('SOCIAL '+(i+1)),url}));
    /* Do not mutate another player while saving. Build an isolated payload first. */
    const next={...p,jersey:String(d.jersey||'').trim(),nick:String(d.nick||'').trim(),bio:String(d.bio||'').trim(),socials:nextSocials};
    Object.assign(p,{jersey:next.jersey,nick:next.nick,bio:next.bio,socials:next.socials});
    try{await rdmDB.collection(RCOL.players).doc(id).set({jersey:next.jersey,updatedAt:rdmStamp()},{merge:true})}catch{}
    await rdmProfileWrite(next);
    rdmRefresh();
    window.adminOpenPlayerProfile(id);
    toast('Profile saved');
  });
};
